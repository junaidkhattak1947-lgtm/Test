ZERO STUDIO — Android APK project

IMPORTANT: Is ZIP mein aapki original HTML app aur Android wrapper shamil hain. Is environment mein Android SDK/Gradle maujood nahi tha, is liye actual APK abhi compile/test nahi hua.

Aapke phone ka file manager .github jaisay dot-walay folders chhupa sakta hai. Is liye GitHub website par visible files upload karne ke baad workflow file website par khud create karein:

1. ZIP extract karein.
2. GitHub repository ke Code page par “Add file” > “Upload files” choose karein.
3. Extracted ZeroStudioAndroid folder ke andar se app folder, build.gradle, gradle.properties aur settings.gradle upload karein. README-UR.txt aur BUILD-WORKFLOW-COPY.txt optional hain. Folder ke andar ja kar files select karein; ZIP ko upload na karein.
4. Upload commit kar dein.
5. Repository par wapas ja kar “Add file” > “Create new file” choose karein.
6. Filename box mein bilkul yeh path likhein: .github/workflows/build-apk.yml
7. BUILD-WORKFLOW-COPY.txt khol kar uska poora text copy karein aur naye file ke editor mein paste karein.
8. “Commit changes” dabayein.
9. “Actions” tab kholein. “Build Zero Studio APK” workflow select karein. Zarurat ho to “Run workflow” dabayein.
10. Build successful hone par run page ke neeche “Artifacts” mein “Zero-Studio-debug-APK” download karein. ZIP extract karke app-debug.apk milegi.

Agar build fail ho, error ka screenshot bhejein; andaza laga kar APK safe ya working hone ka dawa na karein.

SECURITY:
- App manifest mein unnecessary Android permissions add nahi ki gayi; image selection Android file picker se hoti hai.
- Android/Play Protect ke warnings ko force-hide ya bypass nahi kiya ja sakta. Unknown-source warning sideloaded APK par aa sakti hai.
- APK dost ko bhejne se pehle apne phone par install karke test karein. Yeh debug APK hai, independently tested/reviewed release nahi.
